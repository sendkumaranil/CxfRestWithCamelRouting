@javax.xml.bind.annotation.XmlSchema(namespace = "http://resource.example.cxfsoap.com/")
package com.cxfsoap.example.resource;
